from flask import Flask, render_template
import os

app = Flask(__name__)

IMG_FOLDER = os.path.join('static', 'images')

app.config['UPLOAD_FOLDER'] = IMG_FOLDER

@app.route("/")
def Display_IMG():
    Flask_Logo1 = os.path.join(app.config['UPLOAD_FOLDER'], '01_traininghistory.png')

    Flask_Logo2 = os.path.join(app.config['UPLOAD_FOLDER'], '02_Test_NN.png')

    return render_template("website.html", user_image1=Flask_Logo1,user_image2=Flask_Logo2)

if __name__=='__main__':
    app.run(debug=True)