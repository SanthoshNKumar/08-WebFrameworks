from flask import Flask,request,render_template
app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/login")
def login():
    name = request.args.get('nm')
    return f"<h1>{name}</h1>"

if __name__ =='__main__':
    app.run(debug=True) 