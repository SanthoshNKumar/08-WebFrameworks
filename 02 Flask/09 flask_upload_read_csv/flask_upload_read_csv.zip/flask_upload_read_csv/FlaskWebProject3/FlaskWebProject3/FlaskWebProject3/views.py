"""
Routes and views for the flask application.
"""
import os
import pandas as pd
from datetime import datetime
from flask import request,redirect,url_for
from flask import render_template
from FlaskWebProject3 import app

# Read csv file in python_ flask

@app.route('/')
def index():
    return render_template('index.html')

# Get the uploaded files
@app.route("/", methods=['POST'])
def uploadFiles():
    uploaded_file = request.files['file']

    df = pd.read_csv(uploaded_file)
    return render_template('table.html', tables=[df.to_html()], titles=[''])
